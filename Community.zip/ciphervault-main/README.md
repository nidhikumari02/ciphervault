# ciphervault


## Project Description


<h3>It is a project based on blockchain we are using react, vite js, Solidity, Metamask, hardhat and some tools (git,yarn, npm etc).
With CipherValut we can transfer Crypto Currencies from one wallet to another wallet with out any effort, we are using a metamask chrome extension  to test the application. We created a dummy wallet using metamask and tested it successfully  in our local system.
Nowadays, Crypto is a trending headline, People around the globe are interested in crypto and kept their hands into investing and payments in crypto. So we are here to help the folks  to make crypto payment easily. Our project is in a prototype stage, We can also develop this application on large scale so that it can help to blockchain industry, to make people’s  gateway of payments easier in crypto.</h3>
